# D222 bottleneck adapters — Phase 4 CJPE methodology

## Problem statement and data

Phase 4 Court Judgment Prediction predicts binary outcome 0/1 from legal case text. The preserved official inputs are Train/train.json, Train/dev.json and Test/test.json. Test labels are private. Original run records report 994 official dev labels and 1,517 test IDs; macro-F1 is the central metric.

## Architecture and mechanics

A zero-initialized up projection lets each width-32 bottleneck begin as an identity residual on selected feed-forward output layers. The task evidence head is trained alongside the adapters. Data flow: Legal case -> D222 own tokenizer/backbone -> Frozen D222 with width-32 residual FFN adapters -> Token evidence pooling -> Ordered chunk BiGRU -> 2-class logits -> prediction.json.

## Training design and checkpoint selection

Frozen D222 with width-32 residual FFN adapters. Executed v3 runner: `code/v3_t4x2.ipynb`, `code/runner/phase4_cjpe/kaggle_runner.py` with `published_v3_schedule.json`; the six jobs share `EvidenceCaseModel` in `code/runner/phase4_cjpe/models.py`.

## Exact run configuration and resource tradeoff

Experiment family d222; adaptation method adapters; original parent checkpoint SHA-256 08a737d002a71a90ad21f350e25a76f1e70eb172badf0671ff8818d96ea5c46f. Configuration: 256 tokens/chunk, 8 chunks/case, 8192 source characters considered, maximum 12000 training cases, 256 holdout cases per class. Optimizer configuration: backbone learning rate 0.0003, head learning rate 0.0003, gradient accumulation 8, max epochs 4, planned training hours 2.5. Recorded 353 optimizer updates and 2824 seen training examples; selected step 353. Selected checkpoint SHA-256 d08fd295c77a6e4231fedae2f8dac13258e285434bff31cd7a77209018f12840; parameters 224620682, trainable 2540810. Original run completed after nominal deadline: True.

## Measured results

Original Kaggle run: complete; 353 optimizer updates; selected step 353. Official 994-case dev macro-F1 **0.530606** at recorded threshold 0.367270; default 0.5 dev macro-F1 0.442347. Verified prediction ZIP SHA-256 `3c0c236761a6fdc6d87cfac3ebf94cbc518e3f5229b89a02c50f7e888250c35d`, exactly 1,517 IDs. No finished Codabench score for this exact export is established by the supplied screenshot.

## Evaluation mechanics

Official labeled dev cases 994; class supports [497, 497]; confusion matrix rows true 0/1, columns predicted 0/1: [[155, 342], [96, 401]]. At selected threshold 0.367270, macro-F1 0.530606; at threshold 0.5, macro-F1 0.442347. The report keeps these thresholds separate because threshold choice changes the binary predictions. The submitted ZIP has 1,517 unique test IDs and binary labels; no test labels were available to this run.

## Prediction contract and verification

The original prediction ZIP contains one root-level prediction.json with 1,517 unique official test IDs and integer labels restricted to 0 and 1. This package checks the ZIP CRC and SHA-256 against the archived run/verification record. Full model checkpoint tensors remain outside GitHub; their downloaded backup receipts and hashes live in the local Phase 4 study archives.

## Reproducibility and limits

The local dev score uses a threshold recorded in the run; inspect its calibration/selection record before treating it as independent model-selection evidence. A prepared model notebook is source scaffolding, while `v3_t4x2.ipynb` and the Kaggle run evidence identify the executed v3 lineage. Reports and companion notebook were created after training; original scores come from copied artifacts. Model weights and course data are preserved locally, not uploaded to GitHub.
