# C1 BitFit — Phase 4 CJPE methodology

## Problem statement and data

Phase 4 Court Judgment Prediction predicts binary outcome 0/1 from legal case text. The preserved official inputs are Train/train.json, Train/dev.json and Test/test.json. Test labels are private. Original run records report 994 official dev labels and 1,517 test IDs; macro-F1 is the central metric.

## Architecture and mechanics

Only bias parameters in the C1 backbone receive gradients, with a trainable task evidence head. This tests an inexpensive adaptation of the same recurrent hybrid used by C1 full tuning. Data flow: Legal case -> C1 own tokenizer/backbone -> Bias-only backbone tuning -> Token evidence pooling -> Ordered chunk BiGRU -> 2-class logits -> prediction.json.

## Training design and checkpoint selection

Bias-only backbone tuning. Executed v3 runner: `code/v3_t4x2.ipynb`, `code/runner/phase4_cjpe/kaggle_runner.py` with `published_v3_schedule.json`; the six jobs share `EvidenceCaseModel` in `code/runner/phase4_cjpe/models.py`.

## Exact run configuration and resource tradeoff

Experiment family c1; adaptation method bitfit; original parent checkpoint SHA-256 1903b848b39ca9f335c8d9e3add532d5f49718d539b130e6a8348d98d802433e. Configuration: 256 tokens/chunk, 8 chunks/case, 8192 source characters considered, maximum 12000 training cases, 256 holdout cases per class. Optimizer configuration: backbone learning rate 0.0002, head learning rate 0.0003, gradient accumulation 8, max epochs 4, planned training hours 2.5. Recorded 800 optimizer updates and 6400 seen training examples; selected step 400. Selected checkpoint SHA-256 4030ae989c2b84e8074c5ac2637ea877b84de4410dbdc4af173e80d1822c2378; parameters 118799242, trainable 1012618. Original run completed after nominal deadline: True.

## Measured results

Original Kaggle run: complete; 800 optimizer updates; selected step 400. Official 994-case dev macro-F1 **0.535560** at recorded threshold 0.449234; default 0.5 dev macro-F1 0.454764. Verified prediction ZIP SHA-256 `6d5be1e9fab3c623b9bb0323c54a5a95ab01f6421507a8fd9712e37c135d7c15`, exactly 1,517 IDs. No finished Codabench score for this exact export is established by the supplied screenshot.

## Evaluation mechanics

Official labeled dev cases 994; class supports [497, 497]; confusion matrix rows true 0/1, columns predicted 0/1: [[324, 173], [283, 214]]. At selected threshold 0.449234, macro-F1 0.535560; at threshold 0.5, macro-F1 0.454764. The report keeps these thresholds separate because threshold choice changes the binary predictions. The submitted ZIP has 1,517 unique test IDs and binary labels; no test labels were available to this run.

## Prediction contract and verification

The original prediction ZIP contains one root-level prediction.json with 1,517 unique official test IDs and integer labels restricted to 0 and 1. This package checks the ZIP CRC and SHA-256 against the archived run/verification record. Full model checkpoint tensors remain outside GitHub; their downloaded backup receipts and hashes live in the local Phase 4 study archives.

## Reproducibility and limits

The local dev score uses a threshold recorded in the run; inspect its calibration/selection record before treating it as independent model-selection evidence. A prepared model notebook is source scaffolding, while `v3_t4x2.ipynb` and the Kaggle run evidence identify the executed v3 lineage. Reports and companion notebook were created after training; original scores come from copied artifacts. Model weights and course data are preserved locally, not uploaded to GitHub.
